(function(){
	(function(){document.write("<script type='text/javascript' src='tinymce/tinymce.min.js'></script>");}());
	var plantillaID = getUrlParameter('plantilla'); //
	
	
}());	
// ---------------------------------------------------------------------------------- //
// DETECTAR GET URL 


var plantilla1 = '<table style="height: 463px;" width="100%">'+
'<tbody>'+
'<tr>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'</tr>'+
'<tr>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'</tr>'+
'<tr>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'<td style="width: 195px;">&nbsp;</td>'+
'</tr>'+
'</tbody>'+
'</table>';

var plantilla2 = '<div style="text-align:left;width:700px;margin:0 auto"><div style="background-color:#F3F2ED; padding:5px; text-decoration:none; color:#000000;text-align:center;"><h1><a href="#">Free CSS Layouts</a></h1></div><div style="float:left;width:100%"><div style="margin: 0 150px"><p style="margin:0 10px 10px;line-height:1.4"><strong>Content here.</strong></p><p style="margin:0 10px 10px;line-height:1.4">Sapibulumnibh phasellus nulla egestibulum enim pretium elit tincidunt estiquam ultrisque donectetur. Sedcondimentumsan odio hendrerit proin vitae dignis nibh ac justo id congue. Amesintesque vel curabitae volutpat donec alique nasceleifendimentesque montesque rhoncus quis eros. Vestnunc nonummy</p><p style="margin:0 10px 10px;line-height:1.4">Montegeraliquam sed pede in cursus praesenec vestas rhoncus wisi at wisi. Condisseloborttis enim et ipsum mauristie id felit adipiscipit ac auctortorttitor sempor. Vitantesqueat sempus non sed et mus sit vivamus purus netus hendiment. Pretiuma diam et id tempus dolor por wisi sed volutpat facilisi.</p><p style="margin:0 10px 10px;line-height:1.4">Wisiet sus adipit phasellentum elit condissim consecteturpiscing sapien vivamus et congue. Utvel tris quismod cursus liberos elit nisse curabitur tur parturpis tellenterdum. Semperligula curabitae tellentesque nulla trices vestas ristibulum id justo auctor facinia. Natisdonec consequat nibh pellus.</p><p style="margin:0 10px 10px;line-height:1.4">Vestibusodio euisque id elerisus lacus tincidunt sit malesuada lacus pellus parturpiscing. Pellenterdumat maecenatoque cras a magna nibh et quis diam ames et. Laoremvolutpat ac dolor eget eget temper lacus vestibus velit lacus venean. Magnaipsum tellus morbi leo aliquat nulla convallis pellentesque.</p></div></div><div style="margin-bottom:5px;background:#F6F0E0;float:left;width:150px;margin-left:-700px;float:left;width:150px;margin-left:-150px"><p style="margin:0 10px 10px"><strong>Navigation Here</strong></p><ul style="margin:15px 0; padding:0; list-style-type:none;"><li style="margin-bottom:5px;"><a style="padding:5px; text-decoration:none; color:#000000;" href="#">Free CSS Templates</a></li><li style="margin-bottom:5px;"><a style="padding:5px; text-decoration:none; color:#000000;" href="#">Free CSS Layouts</a></li></ul></div><div id="footer"><p style="margin:0 10px 10px;clear:left;width:100%;margin:0;padding:5px 10px;background:#BFBD93;text-align:center;">Footer</p></div></div>';



var Page = (function(){
	var config = {
			$bookBlock : $( '#bb-bookblock' ),
			$navNext : $( '#bb-nav-next' ),
			$navPrev : $( '#bb-nav-prev' ),
			$navFirst : $( '#bb-nav-first' ),
			$navLast : $( '#bb-nav-last' )
		},
		init = function(){
			config.$bookBlock.bookblock( {
				speed : 1000,
				shadowSides : 0.8,
				shadowFlip : 0.4
			});
			initEvents();
		},
		initEvents = function() {
			var $slides = config.$bookBlock.children();
			// add navigation events
			config.$navNext.on( 'click touchstart', function() {
				config.$bookBlock.bookblock( 'next' );
				return false;
			});
			config.$navPrev.on( 'click touchstart', function() {
				config.$bookBlock.bookblock( 'prev' );
				return false;
			});
			config.$navFirst.on( 'click touchstart', function() {
				config.$bookBlock.bookblock( 'first' );
				return false;
			});
			config.$navLast.on( 'click touchstart', function() {
				config.$bookBlock.bookblock( 'last' );
				return false;
			});
		};
		return { init : init };
		return { initEvents : initEvents };
})();

function iniciarEditor(selector){
	tinymce.init({
		selector: selector,
		skin: 'demedallo',
		language_url : 'tinymce/langs/es.js',
		plugins: [
			'advlist autolink preview lists link image media charmap textpattern importcss searchreplace code fullscreen insertdatetime table contextmenu paste'
		],
		inline: true,
		theme: 'modern',
		menubar: true,
		toolbar: false,
		importcss_append: true,
		paste_data_images: true,
		
		insert_toolbar: 'quickimage quicktable',
		selection_toolbar: 'bold italic | quicklink h2 h3 blockquote',

		toolbar1: 'undo redo advlist | styleselect | bold italic | alignleft aligncenter alignright | charmap blockquote | link image media',
		//toolbar2: '',
		
		setup: function(editor){
			editor.addMenuItem(
				'myitem', {
					text: 'Plantilla 1',
					context: 'tools',
					onclick: function(){
						editor.insertContent(plantilla1);
					}
				}
			);
			editor.addMenuItem(
				'myitem2', {
					text: 'Plantilla 2',
					context: 'tools',
					onclick: function(){
						editor.insertContent(plantilla2);
					}
				}
			);
		},
		
		content_css: [
			'../css/bookblock.css'    
		  ]
	});
}

//evitar enter en formularios
function eliminarEnter(formularios){
	$(formularios).keypress(function(e) {
		if (e.which == 13) {
			return false;
		};
	});	
}

function stylesConvert(selectorEdit){
	
	var iCnt = 0;
	values2 = '';
	o= 1;
	
	$( ".BtnPagina" ).click(function( event ) {
		var ID = $(this).attr("id");
		$(".dialogPage").css("display", "none"); 
		$("#pagina-"+ID).css("display", "block"); 
	});
	
	$('#btnGenerar').click(function () {
		if(1 <= iCnt){
			
			$('.dialogPage').each(function() {
				values2 += this.innerHTML + '<hr>';
				o++
			});	
			
			alert(values2);
		}
	});
	
	$('#btAdd').click(function() {
			iCnt = iCnt + 1;
			$('#totalPaginas').text('Paginas Totales: '+iCnt);
			//$('#botonesPaginas').append('<a id="'+iCnt+'" class="BtnPagina btnpage-'+iCnt+' ui-state-default" style="float:left; cursor: default;" href="#"> '+iCnt+'</a>');	AGREGAR BOTONES//
			$('#bb-bookblock').append(
				'<div class="bb-item" id="pagina-'+iCnt+'">'+
					'<div class="bannerTop">'+
						'<p><img src="images/logo-allus.png" />Noti SuRallus</p>'+
					'</div>'+
					'<div class="bb-custom-side">'+
						'<div class="dialogPage" title="Pagina '+iCnt+'">'+iCnt+'</div>'+
					'</div>'+
					'<div class="bb-custom-side">'+
						'<div class="dialogPage" id="pagina-'+iCnt+'" title="Pagina '+iCnt+'">'+'</div>'+
					'</div>'+
				'</div>'
			);
			
		Page.init();
		iniciarEditor(selectorEdit);
	});
	
	$('#btRemove').click(function() { 
		if (iCnt != 0) {
			$('.btnpage-' + iCnt).remove(); 
			$('#pagina-' + iCnt).remove();
			iCnt = iCnt - 1;
		}
		if (iCnt == 0) {
			$('#btSubmit').remove();
			$('#btAdd').removeAttr('disabled');
		}
		Page.init();
	$('#totalPaginas').text('Paginas Totales: '+iCnt);
	});
	
	$('#btCrear').click(function() {
		$( "#finishForm" ).text('');
		i=0;
		var asasas = '';
		
		if (iCnt == 0) {
			alert('No has creado ninguna pagina');
		} else {
			$( ".bb-item" ).each(
			function() {
					if(i == 0){
						i++
					} else {
						asasas += this.innerHTML+'<SEPARADORESWEB>';
						i++
					}
				}
			);
			
		}
		$( "#finishForm" ).append('<label>Titulo publicacion: <input name="nombrePublicacion" type="text" /></label>');
		$( "#finishForm" ).append('<textarea style="display:none;" name="pagina">'+asasas+'</textarea>');
		$( "#finishForm" ).append('<input type="submit" />');
	});
};
	

function getUrlParameter(sParam) {
	var sPageURL = decodeURIComponent(window.location.search.substring(1)),
		sURLVariables = sPageURL.split('&'),
		sParameterName,
		i;

	for (i = 0; i < sURLVariables.length; i++) {
		sParameterName = sURLVariables[i].split('=');

		if (sParameterName[0] === sParam) {
			return sParameterName[1] === undefined ? true : sParameterName[1];
		}
	}
};


