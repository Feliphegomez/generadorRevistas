<?php 

	define("NAME_SERVER","localhost");
	define("USER_SERVER","root");
	define("PASS_SERVER","");
	define("DBNAME_SERVER","diariofg");
	define("TABLA_NAME","paginas");

?>